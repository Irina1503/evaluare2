const slides = document.querySelector('.slides');
const slideImages = document.querySelectorAll('.slide');
let currentIndex = 0;
let slideshowInterval;
let isSlideshowActive = false;

function showSlide(index) {

    slideImages.forEach((slide) => {
        slide.style.opacity = '0'; // Ascundem imaginea
        slide.style.transform = 'translateX(100%)'; // Mutăm imaginea în afacerea ecranului
    });

    const currentSlide = slideImages[index];
    currentSlide.style.opacity = '1'; // Face imaginea vizibilă
    currentSlide.style.transform = 'translateX(0)'; // Tranziția imaginii pe ecran
}

function nextSlide() {
    currentIndex = (currentIndex + 1) % slideImages.length;
    showSlide(currentIndex);
}

function activateSlideshow() {
    
    if (isSlideshowActive) return;

    showSlide(currentIndex);

    slideshowInterval = setInterval(nextSlide, 3000);
    isSlideshowActive = true;
}

document.getElementById('activateSlideshow').addEventListener('dblclick', activateSlideshow);
